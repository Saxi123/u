const Discord = require('discord.js');
const bot = new Discord.Client();
const config = require('./config.json');
const secrets = require('./secrets.json');
const fs = require('fs');

bot.on('ready', () =>{
    console.log('Bot online!')
    console.log('Version: ' + config.version)
    bot.user.setStatus('dnd')
    bot.user.setActivity(bot.guilds.size + ' servers | ' + config.prefix + 'help', {type:'WATCHING'})
})

bot.on('message', msg => {
    
})

bot.login(secrets.token);