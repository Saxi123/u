Before you start using this template, make sure you change the following things:

config.json/prefix
package.json/name -- Make sure this is your bot's exact name, all in lower case, and remove any punctuation from the name, and replace all spaces with underscores(_)
package.json/description
package.json/author
package-lock.json/name

You can use this template for whatever you want, just don't redistribute it claiming you made it. :)